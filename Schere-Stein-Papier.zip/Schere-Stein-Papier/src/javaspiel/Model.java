package javaspiel;

import java.util.Random;

import Model.ELEMENTS;
import Model.STATUS;

public class Model {
	private int pointsUser = 0;
	private int pointsComp = 0;
	
	public enum ELEMENTS {
		ROCK, PAPER, SCISSORS
	};
	
	public enum STATUS{
		USER_WINS, COMP_WINS, NOONE_WINS
	};
	
	public ViewChange updateModel(Action act) { 
		Model.ELEMENTS userSet = act.getNewSet();
		Model.ELEMENTS compSet = generateCompMove();
		Model.STATUS statusValue = STATUS.NOONE_WINS;
		if ((userSet == ELEMENTS.ROCK &&
			compSet == ELEMENTS.SCISSORS) ||
			(userSet == ELEMENTS.SCISSORS &&  
			compSet== ELEMENTS.PAPER) ||
			(userSet == ELEMENTS.PAPER &&  
			compSet== ELEMENTS.ROCK)) {
			statusValue = STATUS.USER_WINS;
			pointsUser++;
		} else if (userSet != compSet) {
			statusValue = STATUS.COMP_WINS;
			pointsComp++;
		}
		return new ViewChange(pointsUser, pointsComp,
				userSet, compSet, statusValue);
	}
	public ELEMENTS generateCompMove() {
		Random myRnd = new Random();
		switch(myRnd.nextInt(3)) {
		case 0:
			return ELEMENTS.ROCK;
		case 1:
			return ELEMENTS.PAPER;
		}
		return ELEMENTS.SCISSORS;
	}
}
