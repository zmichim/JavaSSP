package javaspiel;


public class Action {
private Model.ELEMENTS newSet;

public Action(Model.ELEMENTS newSet) {
	this.newSet = newSet;
}

public Model.ELEMENTS getNewSet() {
	return newSet;
}
}
