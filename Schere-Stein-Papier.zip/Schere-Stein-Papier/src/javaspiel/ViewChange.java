package javaspiel;

public class ViewChange {
private int pointsUser = 0;
private int pointsComp = 0;
private Model.ELEMENTS userSet;
private Model.ELEMENTS compSet;
private Model.STATUS statusValue;

public ViewChange(
	int pointsUser,
	int pointsComp,
	Model.ELEMETNS userSet,
	Model.ELEMENTS compSet,
	Model.STATUS statusValue) {
	this.pointsUser = pointUser;
	this.pointsComp = pointsComp;
	this.userSet = userSet;
	this.compSet =compSet;
	this statusValue = statusValue;
}


}