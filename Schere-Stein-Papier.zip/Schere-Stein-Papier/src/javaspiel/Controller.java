package javaspiel;

public class Controller {
private Model model = null;
private View view = null;

public Controller(Model model) {
	this.model = model;
}

public void setView(View view) {
	this.view = view;
}
public void actionOccurred(Action act) {
	ViewChange vch = model.updateModel(act);
	view.changeView(vch);
}
}
