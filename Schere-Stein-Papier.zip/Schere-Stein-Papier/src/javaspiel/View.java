package javaspiel;

import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.ActionListener;

public class View extends JFrame implements ActionListener{
	private static final long serialVersionUID = 1L;
	private JLabel lbUser = null;
	private JLabel lbComp = null;
	private JLabel lbStatus = null;
	private JLabel lbImgUser = null;
	private JLabel lbImgComp = null;
	private JLabel lbImgStatus = null;
	private JButton btRock = null;
	private JButton btPaper = null;
	private JButton btScissors = null;
	private Controller ctrl = null;
	
	private ImageIcon[] images;
	
	private static final String IMG_PATH = "/package/img/"
	private static final String[] IMG_NAMES = {
			"rock.png",
			"paper.png",
			"scissors.png",
			"smile.png",
			"ind.png",
			"sad.png",
			"quest.png",
			
			
	};
	
	private static final int POS_ROCK = 0;
	private static final int POS_PAPER = 1;
	private static final int POS_SCISSORS = 2;
	private static final int POS_SMILE = 3;
	private static final int POS_INDIFFERENT = 4;
	private static final int POS_SAD = 5;
	private static final int POS_QUEST = 6;
	
	private static final String USER_TXT = "User: ";
	private static final String COMP_TXT = "Computer: ";
	private static final String USERWINS_TXT = "You Win!";
	private static final String COMPWIN_TXT = "Computer Wins!";
	private static final String NOWIN_TXT = "No Winner.";
	
	private static final int FONT_SIZE = 20;
	
	
	
	public class View(Controller ctrl) {
		this.ctrl = ctrl;
		ctrl.setView(this);
		initialize();
		setElements();
		setVisible(true);
	}

	private void initialize();{
	setTitle("rps");
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	getContentPlane().setLayout(new GridBagLayout());
	setSize(500, 400);
	preloadImages();
	}
	private void setElements() {
	add((lbUser = new JLabel(USER_TXT + "-")),
			getConstr(0, 0, 0.33, 0.2));
	add((lbStatus = new JLabel("-")),
			getConstr(1, 0, 0.33, 0.2));
	add((lbComp = new JLabel(COMP_TXT + "-")),
			getConstr(2, 0, 0.33, 0.2));
	
	add((lbImgUser = new JLabel(images[POS_QUEST])),
			getConstr(0, 1, 0.33, 0.4));
	add((lbImgStatus = new JLabel(images[POS_INDIFFERENT])),
			getConstr(1, 1, 0.33, 0.4));
	add((lbImgComp = new JLabel(images[POS_QUEST])),
			getConstr(2, 1, 0.33, 0.4));
	
	add((btRock = new JButton(images[POS_ROCK])),
			getConstr(0, 2, 0.33, 0.4));
	add((btPaper = new JButton(images[POS_PAPER])),
			getConstr(1, 2, 0.33, 0.4));
	ad((btScissors = new JButton(images[POS_SCISSORS])),
			getConstr(2,2 0.33, 0.4));
	
	lbUser.setFont(newFont(Font.SANS_SERIF, Font.BOLD, FONT_SIZE));
	lbStatus.setFont(new Font(Font.SANS_SERIF, Font.BOLD, FONT_SIZE));
	lbComp.setFont(new Font(Font.SANS_SERIF, Font.BOLD, FONT_SIZE));
	
	btRock.addActionListener(this);
	btPaper.addActionListener(this);
	btScissors.addActionListener(this);
	}
	private GridBagConstraints getConstr(int gridx, int gridy, double weightx, double weighty) {
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = gridx;
		gbc.gridy = gridy;
		gbc.weightx = weightx;
		gbc.weighty = weighty;
		return gbc;
	}

	public void changeView(ViewChange vch) {
		lbImgUser.setIcon(getImageByElement(vch.getUserSet()));
		lbImgComp.setIcon(getImageByElement(vch.getCompSet()));
		lbImgStatus.setIcon(getImageByElement(vch.getStatusValue()));

		lbUser.setText(USER_TXT + vch.getPointsUser());
		lb.Comp.setText(COMP_TXT + vch.getPointsComp());
		lbStatus.setText(getTextByStatus(vch.getStatusValue()));
	}

	public ImageIcon getImageByElement(
			Model.ELEMENTS element) {
		switch(element) {
		case ROCK:
			return images[POS_ROCK];
		case PAPER:
			return images[POS_PAPER];
		case SCISSORS:
			return images[POS_SCISSORS];
		}
		return images[POS_QUEST];
		}
	
	public ImageIcon getImageByStatus(
			MODEL.STATUS status) {
		switch(status) {
		case USER_WINS:
			return images[POS_SMILE];
		case NOONE_WINS:
			return images[POS_INDIFFERENT];
		case COMP_WINS:
			return images[POS_SAD];
		}
		return images[POS_QUEST];
		}
	
	public String getTextByStatus(
			MODEL.STATUS status) {
		switch(status) {
		case USER_WINS:
			return USERWINS_TXT;
		case NOONE_WINS:
			return NOWIN_TXT;
		case COMP_WINS:
			return COMPWIN_TXT;
		}
		return "-";
	}
	
	private void preloadImages() {
		images = newImageIcon[IMG_NAMES.length];
		for (int i= 0; i < IMG_NAMES.length; i++) {
			images[i] = new ImagesIcon(getImage(IMG_PATH + IMG_Names[i]));
			
		}
	}
	public BufferedImage getImage(String fileName) {
		URL url = this.getClass().getResource(fileName);
		BufferedImage myImage = null;
		try {
			myImage = ImageIO.read(url);
		} catch (IOException e) {
			e.printStackTrace();
		}
		}
	
@Override
public void actionPerformed(ActionEvent e) {
	if(e.getSourche() == btRock) {
		ctrl.actionOccurred(
				new Action(Model.ELEMENTS.ROCK));
	} else if(e.getSource() == btPaper) {
		ctrl.actionOccurred(
				newAction(Model.ELEMENTS.PAPER));
	} else if(e.getSource() == btScissors) {
		ctrl.actionOccurred(
				new Action(Model.ELEMENTS,SCISSORS));
		
		
	}

}
}

